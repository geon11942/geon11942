using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class Slot : MonoBehaviour, IPointerClickHandler
{
    public Sprite image;
    ItemData _itemData=null;
    bool NeedItem=false;
    GameObject Player;
    GameObject _text;
    void Start()
    {
        Player = GameObject.Find("Player");
        if(image != null)
            gameObject.GetComponent<Image>().sprite = image;
        _text=transform.GetChild(0).gameObject;
        _text.SetActive(false);
    }

    // Update is called once per frame
    void Update()
    {
    }
    public bool CheckNeedItem()
    {
        if(NeedItem)
        {
            return true;
        }
        else 
        {
            return false;
        }
    }
    public void CheckStack()
    {
        if (_itemData.StackGS > 1)
        {
            _text.SetActive(true);
            _text.GetComponent<Text>().text = _itemData.StackGS.ToString();
        }
        else
        {
            _text.SetActive(false);
        }
    }
    public ItemData ItemGS
    {
        get { return _itemData; }
        set 
        { 
            _itemData = value;
            NeedItem=true;
            CheckStack();
            ImageGS = _itemData.ImageGS;
        }
    }
    Sprite ImageGS
    {
        get { return image; }
        set 
        { 
            image = value;
            gameObject.GetComponent<Image>().sprite = image;
        }
    }
    public void OnPointerClick(PointerEventData eventData)
    {
        if (eventData.button == PointerEventData.InputButton.Left)
        {
            Debug.Log("Mouse Click Button : Left");
        }
        //else if (eventData.button == PointerEventData.InputButton.Middle)
        //{
        //    Debug.Log("Mouse Click Button : Middle");
        //}
        else if (eventData.button == PointerEventData.InputButton.Right)
        {
            Debug.Log("Mouse Click Button : Right");
            if(CheckNeedItem())
            {
                Debug.Log("������ ���");
                switch (_itemData.TypeGS)
                {
                    case ItemData.ItemType.Food:
                        Debug.Log("���� ���");
                        UseFood();
                        break;
                    case ItemData.ItemType.Equipent:
                        break;
                    case ItemData.ItemType.Furniture:
                        break;

                }
            }
        }

        //Debug.Log("Mouse Position : " + eventData.position);
        //Debug.Log("Mouse Click Count : " + eventData.clickCount);
    }
    public void UseFood()
    {
        Player.GetComponent<PlayerData>().SetHp = _itemData.F_HpGet;
        Player.GetComponent<PlayerData>().SetHunger = _itemData.F_HungerGet;
        Player.GetComponent<PlayerData>().SetSan = _itemData.F_SanGet;
        _itemData.StackGS=-1;
        CheckStack();
        if(_itemData.StackGS==0)
        {
            _itemData = null;
            image = null;
            gameObject.GetComponent<Image>().sprite = null;
            NeedItem = false;
        }
    }
}
