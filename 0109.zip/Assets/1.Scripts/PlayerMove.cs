using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMove : MonoBehaviour
{
    public float MoveSpeed = 4f;
    public float SpeedPer = 1f;
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        float Horizontal = Input.GetAxis("Horizontal");
        float Vertical = Input.GetAxis("Vertical");

        Vector3 Position=transform.position;

        Position.x += Horizontal * Time.deltaTime * (MoveSpeed * SpeedPer);
        Position.y += Vertical * Time.deltaTime * (MoveSpeed * SpeedPer);

        transform.position = Position;
    }

    private void OnTriggerEnter(Collider other)
    {
        if(other.gameObject.tag=="Item")
        {
            Debug.Log("�浹");
            if (gameObject.GetComponent<Inventory>() != null)
            {
                gameObject.GetComponent<Inventory>().ItemGS = other.gameObject;
            }
            Destroy(other.gameObject);
        }
    }
}
