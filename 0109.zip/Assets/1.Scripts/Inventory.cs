using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Inventory : MonoBehaviour
{
    [SerializeField]
    private Transform slotParent;
    [SerializeField]
    private Slot[] slots;
    int slotIndex;
    GameObject item;
    bool InvenFull = false;
#if UNITY_EDITOR
    private void OnValidate()
    {
        slots = slotParent.GetComponentsInChildren<Slot>();
        slotIndex = 0;
    }
#endif
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    public GameObject ItemGS
    {
        get { return item; }
        set 
        {
            item = value;
            InvenFull=true;
            for (int i = 0; i < slots.Length; i++)
            {
                if (slots[i].CheckNeedItem())
                {
                    if (slots[i].ItemGS.IDGS == item.GetComponent<ItemData>().IDGS && slots[i].ItemGS.MaxStackGS > 1 && slots[i].ItemGS.StackGS < slots[i].ItemGS.MaxStackGS)
                    {
                        if (slots[i].ItemGS.StackGS + item.GetComponent<ItemData>().StackGS > slots[i].ItemGS.MaxStackGS)
                        {
                            item.GetComponent<ItemData>().StackGS = -(slots[i].ItemGS.MaxStackGS - slots[i].ItemGS.StackGS);
                            slots[i].ItemGS.StackGS = slots[i].ItemGS.MaxStackGS - slots[i].ItemGS.StackGS;
                            slots[i].CheckStack();
                            Debug.Log("������ ���� �ʰ�.");
                        }
                        else
                        {
                            slots[i].ItemGS.StackGS = item.GetComponent<ItemData>().StackGS;
                            slots[i].CheckStack();
                            InvenFull = false;
                            item = null;
                            break;
                        }
                    }
                }
            }
            if (item != null)
            {
                for (int i = 0; i < slots.Length; i++)
                {
                    if (!slots[i].CheckNeedItem())
                    {
                        slots[i].ItemGS = item.GetComponent<ItemData>();
                        Debug.Log("ȹ���� ������ ĭ :" + i);
                        InvenFull = false;
                        break;
                    }
                }
            }
            if(InvenFull)
            {
                Debug.Log("�κ��丮 ���� ��. ������ ���");
                //���⿡ ��� ������ �ٴڿ� ������ �ڵ�
            }
        }
    }
}
