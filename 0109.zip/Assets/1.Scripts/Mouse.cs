using UnityEngine;

public class Mouse : MonoBehaviour
{
    ItemData IData;
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
